FICtion
=======

Fractal Image Compression accelerated by GA.

Created for a Bachelor's Thesis at TTI.

Contributor: Valentin Paramonov
