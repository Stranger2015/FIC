package paramonov.valentin.fiction.fic;

public class DomainParams {
    private int id;
    private TransformationParams transformationParams;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public TransformationParams getTransformationParams() {
        return transformationParams;
    }

    public void setTransformationParams(TransformationParams transformationParams) {
        this.transformationParams = transformationParams;
    }
}
