package paramonov.valentin.fiction.hcbc.exception;

public class HCBCDimsDoNotMatchException extends Exception {}
