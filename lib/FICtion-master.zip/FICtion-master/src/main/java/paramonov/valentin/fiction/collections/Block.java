package paramonov.valentin.fiction.collections;

public interface Block {
    int getX();

    int getY();

    int getWidth();

    int getHeight();
}
