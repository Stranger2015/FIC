package paramonov.valentin.fiction.hcbc;

import paramonov.valentin.fiction.collections.QuadTree;

public class HCBCTree extends QuadTree<HCBCTree, HCBCBlock> {
    public HCBCTree() {}
}
