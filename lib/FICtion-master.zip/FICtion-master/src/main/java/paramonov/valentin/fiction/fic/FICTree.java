package paramonov.valentin.fiction.fic;

import paramonov.valentin.fiction.collections.QuadTree;

public class FICTree extends QuadTree<FICTree, RangeBlock> {
    public FICTree() {}
}
