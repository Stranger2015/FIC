package paramonov.valentin.fiction.collections;

public class BlockDimensionsException extends RuntimeException {}
