package paramonov.valentin.fiction.image;

public class ImageDimensionException extends RuntimeException {
    public ImageDimensionException() {
    }

    public ImageDimensionException(String message) {
        super(message);
    }
}
