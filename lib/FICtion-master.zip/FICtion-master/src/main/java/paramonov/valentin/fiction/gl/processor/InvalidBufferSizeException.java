package paramonov.valentin.fiction.gl.processor;

public class InvalidBufferSizeException extends Exception {
}
