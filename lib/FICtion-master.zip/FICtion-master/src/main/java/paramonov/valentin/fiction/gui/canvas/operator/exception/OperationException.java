package paramonov.valentin.fiction.gui.canvas.operator.exception;

public class OperationException extends Exception {
    public OperationException(String msg) {
        super(msg);
    }
}
