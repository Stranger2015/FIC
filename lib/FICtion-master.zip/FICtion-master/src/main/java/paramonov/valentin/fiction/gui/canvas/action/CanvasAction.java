package paramonov.valentin.fiction.gui.canvas.action;

public enum CanvasAction {
    CANVAS_NO_ACTION,
    CANVAS_LOAD_IMAGE,
    CANVAS_REPAINT,
    CANCAS_TRANSFORM,
    CANVAS_CLEAR
}
