package paramonov.valentin.fiction.gui.builder;

public enum Component {
    MAIN_PANEL,
    OPTION_PANEL,
    CANVAS
}
